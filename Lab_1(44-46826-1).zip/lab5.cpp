#include<iostream>
using namespace std;

int func(int x)
{
   int fact=1,count=0;

   for(int i=1;i<=x;i++)
   {
      if(x%i==0)
      {
        count++;
      }

   }

   if(count==2)
   {
     for(int i=1;i<=x;i++)
     {
        fact=fact*i;
     }

   }
   else
   {
     cout<<"Erorr! not a prime number";
   }

   return x=fact;

}

int main()
{
      int a;
      cout<<"Please Enter your value here>> ";
      cin>>a;



     cout<<"YOUR RESULT IS \n"<<func(a);
}
