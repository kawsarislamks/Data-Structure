#include<iostream>
using namespace std;
int main()
{int arr[8]= {1,3,8,1,6,3,9,6,};
int count=0;
for(int i=0;i<8;i++)
    {
        for(int j=i+1;j<8;j++)
{
    if(arr[i]==arr[j] && arr[i]!=0 && arr[j]!=0)
        {
            count++;
            arr[i]=0;
            break;
        }
    }
}
if(count>0)
    {
        for(int i=0;i<8;i++)
            {
                if(arr[i]!=0)
                    cout<<arr[i]<<" ";
            }
        }
        else
            cout<<"Unique ";
}
