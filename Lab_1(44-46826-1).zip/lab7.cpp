#include<iostream>
using namespace std;
int main()
{
  int  arr1[6]= {1,4,6,3,6,9};
  int narr1[6];
  int  arr2[6]= {5,3,7,1,2,6};
  int narr2[6];
  int count=0;


       for(int i=0;i<6;i++)
   {
      for(int j=i+1;j<6;j++)
      {

         if(arr1[i]==arr1[j] && arr1[i]!=0 && arr1[j]!=0)
         {
            count++;

            arr1[i]=0;
              break;
         }
      }
   }
      if(count>0)
      {
         for(int i=0;i<6;i++)
         {
              if(arr1[i]!=0)
              {
                narr1[i]=arr1[i];

              }

        }
      }







       for(int i=0;i<6;i++)
   {
      for(int j=i+1;j<6;j++)
      {

         if(arr2[i]==arr2[j] && arr2[i]!=0 && arr2[j]!=0)
         {
            count++;

            arr2[i]=0;
              break;
         }
      }
   }
      if(count>0)
      {
         for(int i=0;i<6;i++)
         {
              if(arr2[i]!=0)
              {
                narr2[i]=arr2[i];

              }

        }
      }



for(int i=0;i<6;i++)
  {
      for(int j=0;j<6;j++)
      {
            if(narr1[i]==narr2[j])
            {
               cout<<narr1[i]<<" ";
               break;
             }
       }



 }




}
