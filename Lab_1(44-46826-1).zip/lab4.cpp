#include<iostream>
using namespace std;
int main()
{
    int a=3,b=3,c=3,d=3,e=3,f=3,  i,j,  X[3][3],Y[3][3],Z[3][3]  ,XYZ[3][3];

    cout<<"Enter row and column of matrix X: \n";
    cout<<"Row="<<a<<endl;
    //cin>>a;
    cout<<"Column="<<b<<endl;
    //cin>>b;

    cout<<"Enter row and column of matrix Y: \n";
    cout<<"Row="<<c<<endl;
   // cin>>c;
    cout<<"Column="<<d<<endl;
   // cin>>d;

    cout<<"Enter row and column of matrix Z: \n";
    cout<<"Row="<<e<<endl;
   // cin>>e;
    cout<<"Column="<<f<<endl;
   // cin>>f;

    if(a!=c && b!=d && a!=e && b!=f)
    {
        cout<<"Matrix can not performed Addition operation\n";
    }

    cout<<"enter elements of matrix  X: \n";
    for(i=0; i<a;i++)
       for(j=0; j<b; j++)
        cin>>X[i][j];


       cout<<"enter elements of matrix  Y: \n";
       for(i=0;i<c; i++)
         for(j=0; j<d; j++)
        cin>>Y[i][j];


         cout<<"enter elements of matrix  Z: \n";
        for(i=0; i<a; i++)
            for(j=0; j<b; j++)
                cin>>Z[i][j];


        for(i=0; i<a; i++)
            for(j=0; j<b; j++)

                XYZ[i][j] = X[i][j]+Y[i][j]+Z[i][j];

              cout<<"Adding of Matrix: \n";

                for(i=0; i<a; i++)

           {
            for(j=0; j<b; j++)
            cout<<XYZ[i][j]<<" ";
            cout<<"\n";
           }



}
