
#include<iostream>
using namespace std;
int showInfo(int x, int y)
{
    for(int i=x; i<=y; i++)
    {
        if(i%2==0)
        {

        // thats for even number
        }
        else
        {
            cout<<i<<endl; // that is opposite of if condition so that that show only odd number because if condition maintaining for even number
        }

    };
}
int main()
{
    int x,y;
    cout<<"Print all odd number between the range\n\n\n \nEnter your First(1st) value for the Starting point range\n";
    cin>>x;
    cout<<"Enter your Second(2nd) value for the Ending point range\n";
    cin>>y;
    showInfo(x,y);
}
