#include<iostream>
using namespace std;
int main()
{
   int arr[9]= {1,3,8,1,6,3,9,6,1};
   int a;


    int count=0;

    cout<<"Enter the value\n";
      cin>>a;
   for(int i=0;i<9;i++)
   {
           if(arr[i]==a)
           count++;

   }


cout<<"Count of value: ";
   cout<<count;
}
