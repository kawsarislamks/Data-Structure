#include<iostream>
using namespace std;
int main()
{
    int even=0,odd=0, arr[10]={12,32,43,1,54,53,15,64,3,13};

     for(int i=0; i<10; i++)
     {
         if(arr[i]%2==0)
         {
             even++;
         }
         else
            {
                odd++;
            }
     }
     cout<<even<<" even number is here.\n";
     cout<<odd<<" odd number is here.\n";

}
