#include<iostream>
#include<bits/stdc++.h>
using namespace std;
int main()
{
   int arr[] = {8,4,6};
   int limit = sizeof(arr) / sizeof(arr[0]);
   int arr2[limit];


  for(int i=0;i<limit;i++)
    {
      arr2[i] = 0;
    }



   for(int i=0; i<limit; i++)
   {
      if(arr2[i]==1)
        {
         continue;
        }


      int count = 1;


      for(int j = i+1; j<limit; j++)
        {
         if (arr[i] == arr[j])
         {
            arr2[j] = 1;

            count++;
         }
        }
      cout<<" "<<arr[i]<<" occurs  " << count << endl;
   }

}

