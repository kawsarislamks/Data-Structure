#include<iostream>
#include<bits/stdc++.h>
using namespace std;
int main()
{
    int arr[5]={2,3,4,5,2};
    int arr2[5]={3,4,5,2,4};
    int len1=sizeof(arr)/sizeof(arr[0]);
    int len2=sizeof(arr2)/sizeof(arr2[0]);
    int arr3[len1+len2];
    int len3=sizeof(arr3)/sizeof(arr3[0]);
    int ln=0;
    int temp=0;

    for(int i=0;i<len1;i++)
    {
         arr3[i]=arr[i];
    }

    for(int i=len2;i<len3;i++)
    {

        arr3[i]=arr2[ln];
        ln++;


    }




    sort(arr3, arr3+len3);


    for(int i=len3-1;i>=0;i--)
    {
        cout<< arr3[i]<<" ";
    }


}
